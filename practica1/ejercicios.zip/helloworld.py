print 'Hello world'
a = 3
a += 1
print a
print(type(a))
